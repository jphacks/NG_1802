import IngredientReader

ingredient = IngredientReader.IngredientReader("./data/database.csv")

print(ingredient.getIngredient("塩"))